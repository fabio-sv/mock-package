# Changelog

## [1.1.1](https://github.com/FabioSVBBD/mock-package/compare/v1.1.0...v1.1.1) (2023-07-10)


### Bug Fixes

* **workflow:** Added id to release step ([aa3fe23](https://github.com/FabioSVBBD/mock-package/commit/aa3fe2394079d5bd5902c7883c38f10c85d45262))

## [1.1.0](https://github.com/FabioSVBBD/mock-package/compare/v1.0.1...v1.1.0) (2023-07-10)


### Features

* **workflow:** Testing Updated release ([4e34f4f](https://github.com/FabioSVBBD/mock-package/commit/4e34f4fbd580f98cace269288d4868d2335b4c5f))

## [1.0.1](https://github.com/FabioSVBBD/mock-package/compare/v1.0.0...v1.0.1) (2023-07-10)


### Bug Fixes

* **html:** Removed div contents ([1c20cac](https://github.com/FabioSVBBD/mock-package/commit/1c20caca884dba178923b0fa798b0e54aadbdadc))

## 1.0.0 (2023-07-10)


### Features

* **init:** Initialized package ([f21b5d8](https://github.com/FabioSVBBD/mock-package/commit/f21b5d8c2a0c9372f24457b28596f6dfa2580356))


### Bug Fixes

* **workflow:** Fixed permissions.contents ([2e8670a](https://github.com/FabioSVBBD/mock-package/commit/2e8670af7a0ee09dea091a9ad93444d446670cb5))
